# EarnPath

A simple mobile-friendly beginner money-making education app.

## Run it
Open `index.html` in a browser. It works offline and stores challenge progress in the browser.

## Next upgrades
- Add a real database/login
- Add more lessons
- Add verified affiliate resources
- Add payments/premium content
- Package as an Android app
